import java.util.Arrays;
import java.util.LinkedList;

public class GenericQueue<E> extends LinkedList {

    //Created no-args constructor.
     public GenericQueue(){

    }
    public GenericQueue(E[] objects){
        this.addAll(Arrays.asList(objects));
    }

    public void enqueue(E e){
         addLast(e);
    }

    public void dequeue(){
         removeFirst();
    }


}
