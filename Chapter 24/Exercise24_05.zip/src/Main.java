public class Main {
    public static void main (String[]args){
        GenericQueue <String> test = new GenericQueue<>();
        test.enqueue("one");
        test.enqueue("two");
        test.enqueue("three");
        test.enqueue("four");

        System.out.println(test);

        test.dequeue();
        System.out.println(test);

        test.dequeue();
        System.out.println(test);

        test.dequeue();
        System.out.println(test);



    }
}
