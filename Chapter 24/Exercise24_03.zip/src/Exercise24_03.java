class Exercise24_03 {
    public static void main(String[] args) {
        TwoWayLinkedList<Integer> list = new TwoWayLinkedList<>();
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);

        java.util.ListIterator<Integer> iterator = list.iterator();
        iterator.next();
        iterator.next();
        iterator.next();

        //System.out.print(iterator.next() + " ");

        System.out.println();
        while (iterator.hasPrevious()) {
            System.out.print(iterator.previous() + " ");
        }
    }
}
