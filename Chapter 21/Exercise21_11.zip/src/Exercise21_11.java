import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.*;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
public class Exercise21_11 extends Application {
    private Map<String, Integer>[] mapForBoy = new HashMap[10];
    private Map<String, Integer>[] mapForGirl = new HashMap[10];
    private Button btFindRanking = new Button("Find Ranking");
    private ComboBox<Integer> cboYear = new ComboBox<>();
    private ComboBox<String> cboGender = new ComboBox<>();
    private TextField tfName = new TextField();
    private Label lblResult = new Label();
    @Override // Override the start method in the Application class
    public void start(Stage primaryStage) {
        GridPane gridPane = new GridPane();
        gridPane.add(new Label("Select a year:"), 0, 0);
        gridPane.add(new Label("Boy or girl?"), 0, 1);
        gridPane.add(new Label("Enter a name:"), 0, 2);
        gridPane.add(cboYear, 1, 0);
        gridPane.add(cboGender, 1, 1);
        gridPane.add(tfName, 1, 2);
        gridPane.add(btFindRanking, 1, 3);
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setHgap(5);
        gridPane.setVgap(5);
        BorderPane borderPane = new BorderPane();
        borderPane.setCenter(gridPane);
        borderPane.setBottom(lblResult);
        BorderPane.setAlignment(lblResult, Pos.CENTER);
        Scene scene = new Scene(borderPane, 370, 160);
        primaryStage.setTitle("Exercise21_11"); // Set the stage title
        primaryStage.setScene(scene); // Place the scene in the stage
        primaryStage.show(); // Display the stage
        for (int year = 2001; year <= 2010; year++) {
            cboYear.getItems().add(year);
        }
        cboYear.setValue(2001);
        cboGender.getItems().addAll("Male", "Female");
        cboGender.setValue("Male");

        for(int i = 0; i < mapForBoy.length; i++){
            mapForBoy[i] = new HashMap<>();
        }
        for(int i = 0; i < mapForGirl.length; i++){
            mapForGirl[i] = new HashMap<>();
        }

        try {
            int year = 2001;
            for(int i = 0; i < 10; i++) {

                URL url = new URL("http://liveexample.pearsoncmg.com/data/babynamesranking" + String.valueOf(year) + ".txt");
                Scanner input = new Scanner(url.openStream());
                while (input.hasNext()) {
                    String line = input.nextLine();

                    String[] spaces = line.split("[\\s\\xA0]+");

                    String boyName = spaces[1];
                    int boyRanking = Integer.parseInt(spaces[2]);
                    String girlName = spaces[3];
                    int girlRanking = Integer.parseInt(spaces[4]);

                    mapForBoy[i].put(boyName, boyRanking);
                    mapForGirl[i].put(girlName, girlRanking);
                }
                year++;
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        btFindRanking.setOnAction( e -> {
        int yearToIndex = 0;

        switch (cboYear.getValue()){
            case 2001 :
                yearToIndex = 0;
                break;
            case 2002 :
                yearToIndex = 1;
                break;
            case 2003 :
                yearToIndex = 2;
                break;
            case 2004 :
                yearToIndex = 3;
                break;
            case 2005 :
                yearToIndex = 4;
                break;
            case 2006 :
                yearToIndex = 5;
                break;
            case 2007 :
                yearToIndex = 6;
                break;
            case 2008 :
                yearToIndex = 7;
                break;
            case 2009 :
                yearToIndex = 8;
                break;
            case 2010 :
                yearToIndex = 9;
                break;
        }

        ArrayList<Integer> sortedValues = new ArrayList<>();

        if(cboGender.getValue().equalsIgnoreCase("male")) {
            sortedValues.clear();
            for(Map.Entry<String, Integer> entry : mapForBoy[yearToIndex].entrySet()){
                int value = entry.getValue();
                sortedValues.add(value);

            }
        } else {
            sortedValues.clear();
            for (Map.Entry<String, Integer> entry : mapForGirl[yearToIndex].entrySet()) {
                int value = entry.getValue();
                sortedValues.add(value);
            }
        }
            Collections.sort(sortedValues);
            System.out.println(sortedValues);
            Integer rankName = null;
            int rank = 0;

            if (cboGender.getValue().equalsIgnoreCase("male")) {
                rankName = mapForBoy[yearToIndex].get(tfName.getText());
            } else {
                rankName = mapForGirl[yearToIndex].get(tfName.getText());
            }

            if (rankName != null) {
                
                rank = sortedValues.size() - sortedValues.indexOf(rankName);
            }

            if (cboGender.getValue().equalsIgnoreCase("male")) {
                lblResult.setText("Boy name " + tfName.getText() + " ranked number " + rank + ".");
            } else {
                lblResult.setText("Girl name " + tfName.getText() + " ranked number " + rank + ".");
            }
        });

    }
    /**
     * The main method is only needed for the IDE with limited
     * JavaFX support. Not needed for running from the command line.
     */
    public static void main(String[] args) {
        launch(args);
    }
}