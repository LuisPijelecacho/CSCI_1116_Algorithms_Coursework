public class WordOccurrence implements Comparable {

    String word;
    Integer count;
    public WordOccurrence(String word, Integer count){
        this.word = word;
        this.count = count;
    }

    public int getCount(){
        return count;
    }
    @Override
    public String toString(){
        return word + " " + count;
    }

    @Override
    public int compareTo(Object o) {

        return 0;
    }
}
