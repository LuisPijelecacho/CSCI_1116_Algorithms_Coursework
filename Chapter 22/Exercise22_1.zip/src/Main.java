import java.util.Scanner;

public class Main {
    public static void main (String[] args){

        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter a string to see its maximum consecutive substring: ");
        String input = scanner.next();
        System.out.println(maximumConsecutiveSubString(input));


    }
    public static String maximumConsecutiveSubString(String input) {
        char[] temp = input.toCharArray();
        StringBuffer maximumString = new StringBuffer();
        StringBuffer maximumTemp = new StringBuffer();

        for (int i = 0; i < temp.length; i++) {
            if (i == temp.length - 1 || temp[i] >= temp[i + 1]) {
                maximumTemp.append(temp[i]);
                if (maximumTemp.length() > maximumString.length()) {
                    maximumString = maximumTemp;
                }
                maximumTemp = new StringBuffer();
            } else {
                maximumTemp.append(temp[i]);
            }
        }

        return maximumString.toString();
    }
}