import java.util.Scanner;

public class Main {
    public static void main (String[] args){
        Scanner input = new Scanner(System.in);

        System.out.println("Enter string #1: ");
        String first = input.nextLine();

        System.out.println("Enter string #2: ");
        String second = input.nextLine();
        int index = 0;

        char [] firstArray = first.toCharArray();
        char [] secondArray = second.toCharArray();

        if (first.contains(second)){
            for (int i = 0; i < secondArray.length; i++){
                if(secondArray[0] == firstArray[i]){
                        index = i;
                        break;

                }


            }
            System.out.println("Matched at index " + index);

        }
    }
}
